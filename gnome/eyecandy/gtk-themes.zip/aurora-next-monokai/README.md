# Aurora Next Monokai
A Fork of Aurora Next GTK-theme, inspired by the Monokai color scheme.

![Terminal emulator + Gnome Shell's Calendar and Notifications Pane](http://i.imgur.com/MEYe0Dq.jpg)

## Installation:
Clone the git folder to ~/.themes
