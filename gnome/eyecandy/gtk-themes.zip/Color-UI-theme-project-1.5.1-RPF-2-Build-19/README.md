# Color UI

## Description:
Color UI was made with maximum usability in mind, from the window borders to the color scheme, Color UI was made for the user who wants an elegant simple theme that does not look broken. If any part of Color UI has any problems in any of the things I listed as this theme supporting, please notify me and I will try to fix it ASAP! Feedback is always appreciated, if it was not for feedback how else would Color UI improve.

## Supported by this theme:
* gtk3
* gtk2
* metacity
* mutter
* unity
* xfwm4
* openbox
* xfce4-notify
* cinnamon shell

## Requirements for this theme:
* gnome-themes-standard
* murrine (gtk-engine-murrine)
* pixbuf (gdk-pixbuf2)

## Install Instructions:
* Copy the Color-UI folder from this directory to /usr/share/themes!
